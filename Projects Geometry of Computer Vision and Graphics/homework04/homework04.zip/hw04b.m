C = [1;2;-3]
f=1;
K = diag( [1 1 1]);
R = K;


load( 'daliborka_01-ux.mat' );

A=(1/f)*K*R;
P(:,1)=A(:,1);
P(:,2)=A(:,2);
P(:,3)=A(:,3);
P(:,4)=-A*C;

X1 = [0 0 0]';
X2 = [1 0 0]';
X3 = [0 1 0]';

X=[X1.'; X2.'; X3.'];

X1 = [0 0 0 1]';
X2 = [1 0 0 1]';
X3 = [0 1 0 1]';

X1_proj1=P*X1;
X2_proj1=P*X2;
X3_proj1=P*X3;

X1_proj2=X1_proj1/X1_proj1(3);  %here we divide it by lamda so that it will be representing the point on the image plane, which is in 2D
X2_proj2=X2_proj1/X2_proj1(3);
X3_proj2=X3_proj1/X3_proj1(3);

c12=(X1_proj2.' * (K^(-1)).' * K^(-1) * X2_proj2)/(norm(K^(-1)*X1_proj2)*norm(K^(-1)*X2_proj2));
c23=(X2_proj2.' * (K^(-1)).' * K^(-1) * X3_proj2)/(norm(K^(-1)*X2_proj2)*norm(K^(-1)*X3_proj2));
c31=(X3_proj2.' * (K^(-1)).' * K^(-1) * X1_proj2)/(norm(K^(-1)*X3_proj2)*norm(K^(-1)*X1_proj2));

d12=norm(X2-X1);
d23=norm(X3-X2);
d31=norm(X1-X3);


[N1, N2, N3] = p3p_distances( d12, d23, d31, c12, c23, c31  );

N=[N1; N2; N3];

[R C] = p3p_RC( N, u, X, K )
