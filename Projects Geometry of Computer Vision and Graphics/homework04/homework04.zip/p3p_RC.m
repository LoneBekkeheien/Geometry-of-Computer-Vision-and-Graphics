function [R C] = p3p_RC( N, u, X, K )
%P3P_RC  P3P problem - absolute camera pose and orientation
%   [R C] = p3p_RC( N, u, X )
%     
%   Input:
%     N .. 1x3, distances (eta) along rays, single solution, obtained from
%           p3p_distances. If [N1 N2 N3] = p3p_distances( ... ), then for 
%           particular i the distances are 
%                 N = [ N1(i) N2(i) N3(i) ]
%     u .. 2x3, corresponding three image points (column vectors)
%
%     X .. 3x0, corresponding three 3D points (column vectors)
%
%     K .. 3x3 calibration matrix
%       
%   Output:
%     R .. matrix of rotation (3x3)
%     C .. camera centre

    R=[];
    C=[];
    N1=[N(1,1) N(2,1) N(3,1)];
    N2=[N(1,2) N(2,2) N(3,2)];
    N3=[N(1,3) N(2,3) N(3,3)];
    Y1e=N1*X(1,:).'/norm(X(1,:));
    Y2e=N2*X(2,:).'/norm(X(2,:));
    Y3e=N3*X(3,:).'/norm(X(3,:));
    
    Z2e=Y2e-Y1e;
    Z3e=Y3e-Y1e;
    Z1e=Z2e*Z3e;
    
    Z2d=X(2,:)-X(1,:);
    Z3d=X(3,:)-X(1,:);
    Z1d=Z2d*Z3d;
    
    R=[Z1e Z2e Z3e]*inv([Z1d Z2d Z3d]);
    
    
    
end